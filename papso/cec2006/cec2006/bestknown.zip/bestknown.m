% this script runs through the test function suite with the best known optimal solutions!
clear all, format compact
delta = 0.0001;

% test function g01
x01 = [1 1 1 1 1 1 1 1 1 3 3 3 1]';
%[length(x01) 13]
[f01, g01, h01] = mlbsuite(x01, 9, 0, 'g01'),
if any (g01 > eps) | any(h01 > delta), disp('best known solution for g01 is infeasible!'); end

% test function g02
x02 = [ 3.16237443645701 3.12819975856112 3.09481384891456 3.06140284777302 ...
  3.02793443337239 2.99385691314995 2.95870651588255 2.92182183591092 ...
  0.49455118612682 0.48849305858571 0.48250798063845 0.47695629293225 ...
  0.47108462715587 0.46594074852233 0.46157984137635 0.45721400967989 ...
  0.45237696886802 0.44805875597713 0.44435772435707 0.44019839654132]';
%[length(x02) 20]
[f02, g02, h02] = mlbsuite(x02, 2, 0, 'g02')
if any (g02 > eps) | any(h02 > delta), disp('best known solution for g01 is infeasible!'); end


% test function g03
x03 = 1/sqrt(10).*ones(1,10);x03=x03';
%[length(x03) 10]
[f03, g03, h03] = mlbsuite(x03, 0, 1, 'g03')
if any (g03 > eps) | any(h03 > delta), disp('best known solution for g03 is infeasible!'); end

% test function g04
x04 = [78, 33, 29.995256025682, 45, 36.775812905788]';
%[length(x04) 5]
[f04, g04, h04] = mlbsuite(x04, 6, 0, 'g04')
if any (g04 > eps) | any(h04 > delta), disp('best known solution for g04 is infeasible!'); end

% test function g05
x05 = [ 679.945373228304,1026.06707557558,0.118876326429568,-0.396233571270012]';
%[length(x05) 4]
[f05, g05, h05] = mlbsuite(x05, 2, 3, 'g05')
if any (g05 > eps) | any(h05 > delta), disp('best known solution for g05 is infeasible!'); end

% test function g06
% x06 = [14.0950000342195	0.842960856300164]';
x06=[14.0950000000000006400000000      0.8429607892154795668000000]';
%[length(x06) 2]
[f06, g06, h06] = mlbsuite(x06, 2, 0, 'g06')
if any (g06 > eps) | any(h06 > delta), disp('best known solution for g06 is infeasible!'); end

% test function g07
x07 = [2.17201138162702          2.36364428655598         8.77391588155975 ...
5.09596542736529         0.990651471937976         1.43058397145114  ...
1.32167416187636           9.8287506140379         8.28012148117864 ...
8.37590246299451]';
%[length(x07) 10]
[f07, g07, h07] = mlbsuite(x07, 8, 0, 'g07')
if any (g07 > eps) | any(h07 > delta), disp('best known solution for g07 is infeasible!'); end

% test function g08
x08 = [1.2279713, 4.2453733]';
%[length(x08) 2]
[f08, g08, h08] = mlbsuite(x08, 2, 0, 'g08')
if any (g08 > eps) | any(h08 > delta), disp('best known solution for g08 is infeasible!'); end

% test function g09
x09 = [2.330499, 1.951372, -0.4775414, 4.365726, -0.6244870, 1.038131, 1.594227]';
%[length(x09) 7]
[f09, g09, h09] = mlbsuite(x09, 4, 0, 'g09')
if any (g09 > eps) | any(h09 > delta), disp('best known solution for g09 is infeasible!'); end

% test function g10
x10 = [579.3167, 1359.943, 5110.071, 182.0174, 295.5985, 217.9799, 286.4162, 395.5979]';
%[length(x10) 8]
[f10, g10, h10] = mlbsuite(x10, 6, 0, 'g10') 
if any (g10 > eps) | any(h10 > delta), disp('best known solution for g10 is infeasible!'); end

% test function g11
x11 = [1/sqrt(2),1/2]';
%[length(x11) 2]
[f11, g11, h11] = mlbsuite(x11, 0, 1, 'g11')
if any (g11 > eps) | any(h11 > delta), disp('best known solution for g11 is infeasible!'); end

% test function g12
x12 = [5, 5, 5]';
%[length(x12) 3]
[f12, g12, h12] = mlbsuite(x12, 1, 0, 'g12')
if any (g12 > eps) | any(h12 > delta), disp('best known solution for g12 is infeasible!'); end

% test function g13
x13 = [-1.717143, 1.595709, 1.827247, -0.7636413, -0.763645]';
%[length(x13) 5]
[f13, g13, h13] = mlbsuite(x13, 0, 3, 'g13')
if any (g13 > eps) | any(h13 > delta), disp('best known solution for g13 is infeasible!'); end

% test function g14
x14 = [0.036002;0.151412;0.783686;0.001725;0.484752;0.000695;0.028175;0.017604;0.038714;0.093207];
%[length(x14) 10]
[f14, g14, h14] = mlbsuite(abs(x14), 0, 3, 'g14')
if any (g14 > eps) | any(h14 > delta), disp('best known solution for g14 is infeasible!'); end

% test function g15
x15=[3.51211626026935 0.216988345475683 3.55217615445509]';
%[length(x15) 3]
[f15, g15, h15] = mlbsuite(x15, 0, 2, 'g15')
if any (g15 > eps) | any(abs(h15) > delta), disp('best known solution for g15 is infeasible!'); end

% test function g16
x16=[705.1745807	68.60000003	102.9	282.3249258	37.58412402]';
%[length(x16) 5]
[f16, g16, h16] = mlbsuite(x16, 38, 0, 'g16')
if any (g16 > eps) | any(abs(h16) > delta), disp('best known solution for g16 is infeasible!'); end

% test function g17
x17 = [212.684440144685   89.1588384165537   368.447892659317  409.03379817159 4.16436988876356 0.0680394595246655 ]';  
%[length(x17) 6]
[f17, g17, h17] = mlbsuite(x17, 0, 4, 'g17')
if any (g17 > eps) | any(abs(h17) > delta), disp('best known solution for g17 is infeasible!'); end

% test function g18
x18=[-0.9890005492667746	0.1479118418638228	-0.6242897641574451 ...
-0.7811841737429015	-0.9876159387318453	0.1504778305249072 ...
-0.6225959783340022	-0.782543417629948	0.0]';
%[length(x18) 9]
[f18, g18, h18] = mlbsuite(x18, 13, 0, 'g18')
if any (g18 > eps) | any(abs(h18) > delta), disp('best known solution for g18 is infeasible!'); end

% test function g19
x19 = [0 6.08597252436373e-033  3.94600628013917  -2.35103745208393e-032  3.28318162727873  10 5.74431051614192e-033    -1.15517863716213e-032     -2.6336322104807e-032  -3.50389001765656e-033    0.370762125835098    0.278454209512692   0.523838440499861     0.388621589976956   0.29815843730292]';
%[length(x19) 15]
[f19, g19, h19] = mlbsuite(x19, 5, 0, 'g19')
if any (g19 > eps) | any(abs(h19) > delta), disp('best known solution for g19 is infeasible!'); end

% test function g20
x20 = [9.53E-7; 0; 4.21E-3; 1.039E-4; 0; 0; 2.072E-1; 5.979E-1; 1.298E-1; 3.35E-2; 1.711E-2; 8.827E-3; 4.657E-10; 0; 0; 0; 0; 0; 2.868E-4; 1.193E-3; 8.332E-5; 1.239E-4; 2.07E-5; 1.829E-5];
%[length(x20) 24]
[f20, g20, h20] = mlbsuite(x20, 6, 14, 'g20')
if any (g20 > eps) | any(abs(h20) > delta), disp('best known solution for g20 is infeasible!'); end

% test function g21
x21 = [193.7783493; 0; 17.3272116; 100.0156586; 6.684592154; 5.991503693; 6.214545462];
%x21 = [193.7245101; 0; 17.3191887; 100.0478978; 6.684451854; 5.991684284; 6.214516489];
%[length(x21) 7]
[f21, g21, h21] = mlbsuite(x21, 1, 5, 'g21') 
if any (g21 > eps) | any(abs(h21) > delta), disp('best known solution for g21 is infeasible!'); end

% test function g22
x22 = [382.902205024722          722.160248057235          8628.37165748565...  
2193.75072398697          9951396.42651277          18846563.1497325  ...
11202040.4237547          199.513964265138          387.979595762463  ...
230.486035734882          251.534368502685          547.979595762463  ...
114.833658841478          27.3031863627897          127.658538197503  ...
52.0204042375569           160.00000000001          4.87126621518417   ...
4.61001876994325          3.95163603081052          2.48660555896315  ...
5.07517381524383]';
%[length(x22) 22]
[f22, g22, h22] = mlbsuite(x22, 1, 19, 'g22') 
if any (g22 > eps) | any(abs(h22) > delta), disp('best known solution for g22 is infeasible!'); end

% test function g23
x23 = [0  99.9999000001 5.58738477217701e-026  100  0.000099999999  0   100 200 0.01]';
%[length(x23) 9]
[f23, g23, h23] = mlbsuite(x23, 2, 4, 'g23')
if any (g23 > eps) | any(abs(h23) > delta), disp('best known solution for g23 is infeasible!'); end

% test function g24
% x24 = [2.3295; 3.17846];
x24 = [2.329520197477607; 3.17849307411768];
%[length(x24) 2]
[f24, g24, h24] = mlbsuite(x24, 2, 0, 'g24')
if any (g24 > eps) | any(abs(h24) > delta), disp('best known solution for g24 is infeasible!'); end

% this script runs through the test function suite with the best known optimal solutions!
% clear all, format compact
delta = 0.0001;

% test function g01
x01 = [1 1 1 1 1 1 1 1 1 3 3 3 1]';
%[length(x01) 13]
[f01, g01, h01] = mlbsuite(x01, 9, 0, 'g01'),
if any (g01 > eps) | any(h01 > delta), disp('best known solution for g01 is infeasible!'); end

% test function g02
%[length(x02) 20]
x02=[   3.16246061572185   3.12833142812967   3.09479212988791   3.06145059523469...
   3.02792915885555   2.99382606701730   2.95866871765285   2.92184227312450...
   0.49482511456933   0.48835711005490   0.48231642711865   0.47664475092742...
    0.47129550835493   0.46623099264167   0.46142004984199   0.45683664767217...
       0.45245876903267   0.44826762241853   0.44424700958760   0.44038285956317]';
%f02*=-0.80361910412559
[f02, g02, h02] = mlbsuite(x02, 2, 0, 'g02')
if any (g02 > eps) | any(h02 > delta), disp('best known solution for g01 is infeasible!'); end


% test function g03
% x03 = 1/sqrt(10).*ones(1,10);x03=x03';
x03=[0.31624357647283069 0.316243577414338339 0.316243578012345927 0.316243575664017895 0.316243578205526066 0.31624357738855069 0.316243575472949512 0.316243577164883938 0.316243578155920302 0.316243576147374916 ]';
%[length(x03) 10]
%f03*=-1.00050010001000;
[f03, g03, h03] = mlbsuite(x03, 0, 1, 'g03')
if any (g03 > eps) | any(h03 > delta), disp('best known solution for g03 is infeasible!'); end

% test function g04
x04=[78 33 29.9952560256815985 45 36.7758129057882073 ]';
%[length(x04) 5]
%f04*=-3.066553867178332e+004;
[f04, g04, h04] = mlbsuite(x04, 6, 0, 'g04')
if any (g04 > eps) | any(h04 > delta), disp('best known solution for g04 is infeasible!'); end

% test function g05
x05=[679.945148297028709 1026.06697600004691 0.118876369094410433 -0.39623348521517826 ]';
%[length(x05) 4]
%f05*=5126.4967140071
[f05, g05, h05] = mlbsuite(x05, 2, 3, 'g05')
if any (g05 > eps) | any(h05 > delta), disp('best known solution for g05 is infeasible!'); end

% test function g06
% x06 = [14.0950000342195	0.842960856300164]';
x06=[14.0950000000000006400000000      0.8429607892154795668000000]';
% x06=[14.09499999999999   0.84296078921546]';
%[length(x06) 2]
%f06*=-6961.81387558015;
[f06, g06, h06] = mlbsuite(x06, 2, 0, 'g06')
if any (g06 > eps) | any(h06 > delta), disp('best known solution for g06 is infeasible!'); end

% test function g07
x07 = [  2.17199634142692           2.3636830416034          8.77392573913157...
          5.09598443745173         0.990654756560493          1.43057392853463...
1.32164415364306          9.82872576524495           8.2800915887356  8.3759266477347]';
%[length(x07) 10]
%f07*=24.30620906818;
[f07, g07, h07] = mlbsuite(x07, 8, 0, 'g07')
if any (g07 > eps) | any(h07 > delta), disp('best known solution for g07 is infeasible!'); end

% test function g08
x08 = [1.22797135260752599 4.24537336612274885 ]';
%[length(x08) 2]
%f08*=-0.0958250414180359
[f08, g08, h08] = mlbsuite(x08, 2, 0, 'g08')
if any (g08 > eps) | any(h08 > delta), disp('best known solution for g08 is infeasible!'); end

% test function g09
x09 = [2.33049935147405174 1.95137236847114592 -0.477541399510615805 4.36572624923625874 -0.624486959100388983 1.03813099410962173 1.5942266780671519 ]';
%[length(x09) 7]
%f09*=680.630057374402
[f09, g09, h09] = mlbsuite(x09, 4, 0, 'g09')
if any (g09 > eps) | any(h09 > delta), disp('best known solution for g09 is infeasible!'); end

% test function g10
x10 = [579.306685017979589 1359.97067807935605 5109.97065743133317 182.01769963061534 295.601173702746792 217.982300369384632 286.41652592786852 395.601173702746735 ]';
%[length(x10) 8]
%f10*=7049.24802052867
[f10, g10, h10] = mlbsuite(x10, 6, 0, 'g10') 
if any (g10 > eps) | any(h10 > delta), disp('best known solution for g10 is infeasible!'); end

% test function g11
% x11 = [1/sqrt(2),1/2]';
x11=[-0.707036070037170616 0.500000004333606807 ]';
%[length(x11) 2]
%f11*=0.7499
[f11, g11, h11] = mlbsuite(x11, 0, 1, 'g11')
if any (g11 > eps) | any(h11 > delta), disp('best known solution for g11 is infeasible!'); end

% test function g12
x12 = [5, 5, 5]';
%[length(x12) 3]
[f12, g12, h12] = mlbsuite(x12, 1, 0, 'g12')
if any (g12 > eps) | any(h12 > delta), disp('best known solution for g12 is infeasible!'); end

% test function g13
x13 = [-1.71714224003          1.59572124049468           1.8272502406271 -0.763659881912867         -0.76365986736498]';
%[length(x13) 5]
%f13*=0.053941514041898
[f13, g13, h13] = mlbsuite(x13, 0, 3, 'g13')
if any (g13 > eps) | any(h13 > delta), disp('best known solution for g13 is infeasible!'); end

% test function g14
x14=[  0.0406684113216282         0.147721240492452         0.783205732104114...
       0.00141433931889084         0.485293636780388      0.000693183051556082...
       0.0274052040687766        0.0179509660214818        0.0373268186859717  0.0968844604336845]';
%[length(x14) 10]
%f14*=-47.7648884594915
[f14, g14, h14] = mlbsuite(abs(x14), 0, 3, 'g14')
if any (g14 > eps) | any(h14 > delta), disp('best known solution for g14 is infeasible!'); end

% test function g15
x15=[3.51212812611795133 0.216987510429556135 3.55217854929179921 ]';
%[length(x15) 3]
%f15*=961.715022289961
[f15, g15, h15] = mlbsuite(x15, 0, 2, 'g15')
if any (g15 > eps) | any(abs(h15) > delta), disp('best known solution for g15 is infeasible!'); end

% test function g16
x16=[705.174537070090537 68.5999999999999943 102.899999999999991 282.324931593660324 37.5841164258054832 ]';
%[length(x16) 5]
%f16*=-1.90515525853479
[f16, g16, h16] = mlbsuite(x16, 38, 0, 'g16')
if any (g16 > eps) | any(abs(h16) > delta), disp('best known solution for g16 is infeasible!'); end

% test function g17
x17 = [201.784467214523659 99.9999999999999005 383.071034852773266 420 -10.9076584514292652 0.0731482312084287128  ]';  
%[length(x17) 6]
%f17*=8853.53967480648
[f17, g17, h17] = mlbsuite(x17, 0, 4, 'g17')
if any (g17 > eps) | any(abs(h17) > delta), disp('best known solution for g17 is infeasible!'); end

% test function g18
x18=[-0.657776192427943163 -0.153418773482438542 0.323413871675240938 -0.946257611651304398 -0.657776194376798906 -0.753213434632691414 0.323413874123576972 -0.346462947962331735 0.59979466285217542 ]';
%[length(x18) 9]
%f18*=-0.866025403784439
[f18, g18, h18] = mlbsuite(x18, 13, 0, 'g18')
if any (g18 > eps) | any(abs(h18) > delta), disp('best known solution for g18 is infeasible!'); end

% test function g19
x19 = [1.66991341326291344e-17 3.95378229282456509e-16 3.94599045143233784 1.06036597479721211e-16 3.2831773458454161 9.99999999999999822 1.12829414671605333e-17 1.2026194599794709e-17 2.50706276000769697e-15 2.24624122987970677e-15 0.370764847417013987 0.278456024942955571 0.523838487672241171 0.388620152510322781 0.298156764974678579 ]';
%[length(x19) 15]
%f19*=32.6555929502463
[f19, g19, h19] = mlbsuite(x19, 5, 0, 'g19')
if any (g19 > eps) | any(abs(h19) > delta), disp('best known solution for g19 is infeasible!'); end

% test function g20
x20=[1.28582343498528086e-18 4.83460302526130664e-34 0 0 6.30459929660781851e-18 7.57192526201145068e-34 5.03350698372840437e-34 9.28268079616618064e-34 0 1.76723384525547359e-17 3.55686101822965701e-34 2.99413850083471346e-34 0.158143376337580827 2.29601774161699833e-19 1.06106938611042947e-18 1.31968344319506391e-18 0.530902525044209539 0 2.89148310257773535e-18 3.34892126180666159e-18 0 0.310999974151577319 5.41244666317833561e-05 4.84993165246959553e-16 ]';
%[length(x20) 24]
%infeasible
[f20, g20, h20] = mlbsuite(x20, 6, 14, 'g20')
if any (g20 > eps) | any(abs(h20) > delta), disp('best known solution for g20 is infeasible!'); end

% test function g21
x21 = [193.724510070034967 5.56944131553368433e-27 17.3191887294084914 100.047897801386839 6.68445185362377892 5.99168428444264833 6.21451648886070451 ]';
%[length(x21) 7]
%f21*= 193.724510070035
[f21, g21, h21] = mlbsuite(x21, 1, 5, 'g21') 
if any (g21 > eps) | any(abs(h21) > delta), disp('best known solution for g21 is infeasible!'); end

% test function g22
x22 = [236.430975504001054 135.82847151732463 204.818152544824585 6446.54654059436416 3007540.83940215595 4074188.65771341929 32918270.5028952882 130.075408394314167 170.817294970528621 299.924591605478554 399.258113423595205 330.817294971142758 184.51831230897065 248.64670239647424 127.658546694545862 269.182627528746707 160.000016724090955 5.29788288102680571 5.13529735903945728 5.59531526444068827 5.43444479314453499 5.07517453535834395 ]';
%[length(x22) 22]
%f22*=236.430975504001
[f22, g22, h22] = mlbsuite(x22, 1, 19, 'g22') 
if any (g22 > eps) | any(abs(h22) > delta), disp('best known solution for g22 is infeasible!'); end

% test function g23
x23 = [0.00510000000000259465 99.9947000000000514 9.01920162996045897e-18 99.9999000000000535 0.000100000000027086086 2.75700683389584542e-14 99.9999999999999574 200 0.0100000100000100008 ]';
%[length(x23) 9]
%f23*=-400.055099999999584 
[f23, g23, h23] = mlbsuite(x23, 2, 4, 'g23')
if any (g23 > eps) | any(abs(h23) > delta), disp('best known solution for g23 is infeasible!'); end

% test function g24
x24 = [2.32952019747762  3.17849307411774]';
%[length(x24) 2]
%f24*=-5.50801327159536
[f24, g24, h24] = mlbsuite(x24, 2, 0, 'g24')
if any (g24 > eps) | any(abs(h24) > delta), disp('best known solution for g24 is infeasible!'); end
